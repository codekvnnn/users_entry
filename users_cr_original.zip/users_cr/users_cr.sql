INSERT INTO users (first_name, last_name, email) VALUES ('John', 'Doe', 'johndoe@example.com');
INSERT INTO users (first_name, last_name, email) VALUES ('Mary', 'Doe', 'marydoe@example.com');
INSERT INTO users (first_name, last_name, email) VALUES ('Freddy', 'Doe', 'freddydoe@example.com');
